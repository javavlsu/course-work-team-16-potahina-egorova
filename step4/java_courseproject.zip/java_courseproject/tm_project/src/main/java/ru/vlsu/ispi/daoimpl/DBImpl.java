package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 

import java.util.List; 
import java.util.Map;
import java.util.HashMap;

public class DBImpl {
	public Map<Integer, User> users; 
	public Map<Integer, Task> tasks; 
	public Map<Integer, TaskList> task_lists;
	public Map<Integer, TaskExecutionLog> logs; 
	public Map<Integer, Achievement> achievements; 
	public Map<Integer, UserAchievement> user_achievements;
	public Map<Integer, TimerMode> timer_modes; 
	public Map<Integer, MusicMedia> music_media_t; 
	public Map<Integer, VisualMedia> visual_media_t; 
	public Map<Integer, Notification> notifications; 

	private static DBImpl instance = new DBImpl();

	private DBImpl() {
		this.users = new HashMap<Integer, User>(); 
		this.tasks = new HashMap<Integer, Task>(); 
		this.task_lists = new HashMap<Integer, TaskList>();
		this.logs = new HashMap<Integer, TaskExecutionLog>();
		this.achievements = new HashMap<Integer, Achievement>();
		this.user_achievements = new HashMap<Integer, UserAchievement>();
		this.timer_modes = new HashMap<Integer, TimerMode>();
		this.music_media_t = new HashMap<Integer, MusicMedia>();
		this.visual_media_t = new HashMap<Integer, VisualMedia>();
		this.notifications = new HashMap<Integer, Notification>();
	} 

	public static DBImpl init() {
		return instance; 
	}
}