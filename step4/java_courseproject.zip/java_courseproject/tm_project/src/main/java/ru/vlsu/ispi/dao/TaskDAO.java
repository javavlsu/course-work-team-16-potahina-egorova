package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface TaskDAO {
	public void create(Task task); 

	public void update(Task task); 

	public void delete(int id); 

	public Task getById(int id); 

	public List<Task> getAll(); 
}