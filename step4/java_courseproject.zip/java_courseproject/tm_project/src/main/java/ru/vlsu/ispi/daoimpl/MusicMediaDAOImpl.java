package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*; 

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class MusicMediaDAOImpl implements MusicMediaDAO {
	public void create(MusicMedia music_media) { 
		DBImpl impl = DBImpl.init(); 
		impl.music_media_t.put(music_media.getId(), music_media); 
	} 

	public void update(MusicMedia music_media) { 
		DBImpl impl = DBImpl.init(); 
		impl.music_media_t.put(music_media.getId(), music_media); 
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.music_media_t.remove(id);
	} 

	public MusicMedia getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.music_media_t.get(id);
	} 

	public List<MusicMedia> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.music_media_t.values()); 
		return list; 
	} 
}