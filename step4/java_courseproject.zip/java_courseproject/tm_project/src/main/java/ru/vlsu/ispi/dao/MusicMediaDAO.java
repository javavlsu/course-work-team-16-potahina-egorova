package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface MusicMediaDAO {
	public void create(MusicMedia music_media);

	public void update(MusicMedia music_media);

	public void delete(int id); 

	public MusicMedia getById(int id);

	public List<MusicMedia> getAll(); 
}