package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface VisualMediaDAO {
	public void create(VisualMedia visual_media); 

	public void update(VisualMedia visual_media);

	public void delete(int id); 

	public VisualMedia getById(int id); 

	public List<VisualMedia> getAll(); 
}