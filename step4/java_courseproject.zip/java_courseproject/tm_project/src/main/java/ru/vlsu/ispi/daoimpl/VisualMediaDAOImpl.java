package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*;

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class VisualMediaDAOImpl implements VisualMediaDAO {
	public void create(VisualMedia visual_media) { 
		DBImpl impl = DBImpl.init(); 
		impl.visual_media_t.put(visual_media.getId(), visual_media); 
	} 

	public void update(VisualMedia visual_media) { 
		DBImpl impl = DBImpl.init(); 
		impl.visual_media_t.put(visual_media.getId(), visual_media);
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.visual_media_t.remove(id);
	} 

	public VisualMedia getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.visual_media_t.get(id);
	} 

	public List<VisualMedia> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.visual_media_t.values()); 
		return list; 
	} 
}