package ru.vlsu.ispi.beans; 

public class Notification extends BaseBean {
	private int id; 
	private int user_id; 
	private int task_id;
	private String title; 
	private String text; 
	private boolean is_read; 

	public void setUserId(int user_id) {
		this.user_id = user_id; 
	} 

	public int getUserId() {
		return this.user_id; 
	} 

	public void setTaskId(int task_id) {
		this.task_id = task_id; 
	} 

	public int getTaskId() {
		return this.task_id; 
	}

	public void setTitle(String title) {
		this.title = title; 
	} 

	public String getTitle() {
		return this.title; 
	} 

	public void setText(String text) {
		this.text = text; 
	} 

	public String getText() {
		return this.text; 
	} 

	public void setIsRead(boolean is_read) {
		this.is_read = is_read; 
	} 

	public boolean getIsRead() {
		return this.is_read; 
	} 
}