package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List; 
import java.util.Map;

public interface TimerModeDAO {
	public void create(TimerMode timer_mode);

	public void update(TimerMode timer_mode);

	public void delete(int id);

	public TimerMode getById(int id); 

	public List<TimerMode> getAll();
}