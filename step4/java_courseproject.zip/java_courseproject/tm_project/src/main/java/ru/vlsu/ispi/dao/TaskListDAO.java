package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface TaskListDAO {
	public void create(TaskList task_list); 

	public void update(TaskList task_list);

	public void delete(int id);

	public TaskList getById(int id);

	public List<TaskList> getAll();
}