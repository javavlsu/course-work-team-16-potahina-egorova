package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface TaskExecutionLogDAO {
	public void create(TaskExecutionLog log);

	public void update(TaskExecutionLog log);

	public void delete(int id);

	public TaskExecutionLog getById(int id);

	public List<TaskExecutionLog> getAll(); 
}