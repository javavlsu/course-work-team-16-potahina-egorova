package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List; 
import java.util.Map;

public interface UserDAO {
	public void create(User user);

	public void update(User user); 

	public void delete(int id);

	public User getById(int id);

	public List<User> getAll(); 
}