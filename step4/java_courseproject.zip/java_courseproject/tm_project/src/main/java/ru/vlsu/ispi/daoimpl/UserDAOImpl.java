package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*;

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class UserDAOImpl implements UserDAO {
	public void create(User user) { 
		DBImpl impl = DBImpl.init(); 
		impl.users.put(user.getId(), user); 
	} 

	public void update(User user) { 
		DBImpl impl = DBImpl.init(); 
		impl.users.put(user.getId(), user); 
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.users.remove(id);
	} 

	public User getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.users.get(id);
	} 

	public List<User> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.users.values()); 
		return list; 
	} 
}