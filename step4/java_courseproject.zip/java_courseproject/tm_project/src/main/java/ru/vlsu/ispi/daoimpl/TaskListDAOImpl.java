package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*;

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class TaskListDAOImpl implements TaskListDAO {
	public void create(TaskList task_list) { 
		DBImpl impl = DBImpl.init(); 
		impl.task_lists.put(task_list.getId(), task_list); 
	} 

	public void update(TaskList task_list) { 
		DBImpl impl = DBImpl.init(); 
		impl.task_lists.put(task_list.getId(), task_list); 
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.task_lists.remove(id);
	} 

	public TaskList getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.task_lists.get(id); 
	} 

	public List<TaskList> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.task_lists.values()); 
		return list; 
	} 
}