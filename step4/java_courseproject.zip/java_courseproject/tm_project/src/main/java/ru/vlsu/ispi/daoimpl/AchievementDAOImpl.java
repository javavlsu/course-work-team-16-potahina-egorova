package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*; 

import java.util.List; 
import java.util.Map; 
import java.util.ArrayList;

public class AchievementDAOImpl implements AchievementDAO {
	public void create(Achievement achievement) { 
		DBImpl impl = DBImpl.init(); 
		impl.achievements.put(achievement.getId(), achievement);
	} 

	public void update(Achievement achievement) { 
		DBImpl impl = DBImpl.init(); 
		impl.achievements.put(achievement.getId(), achievement); 
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.achievements.remove(id);
	} 

	public Achievement getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.achievements.get(id);
	} 

	public List<Achievement> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList<Achievement> list = new ArrayList<>(impl.achievements.values()); 
		return list; 
	} 
}