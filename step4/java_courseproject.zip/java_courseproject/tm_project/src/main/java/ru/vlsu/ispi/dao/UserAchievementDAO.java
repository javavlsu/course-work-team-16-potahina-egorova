package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface UserAchievementDAO {
	public void create(UserAchievement user_achievement);

	public void update(UserAchievement user_achievement); 

	public void delete(int id);

	public UserAchievement getById(int id);

	public List<UserAchievement> getAll(); 
}