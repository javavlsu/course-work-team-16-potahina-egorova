package ru.vlsu.ispi.beans; 

public class MusicMedia extends BaseBean {
	private int id; 
	private String name; 
	private String url; 

	public void setName(String name) {
		this.name = name; 
	} 

	public String getName() {
		return this.name; 
	} 

	public void setUrl(String url) {
		this.url = url; 
	} 

	public String getUrl() {
		return this.url; 
	}
}