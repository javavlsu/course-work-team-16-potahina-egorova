package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface NotificationDAO {
	public void create(Notification notification); 

	public void update(Notification notification); 

	public void delete(int id); 

	public Notification getById(int id);

	public List<Notification> getAll(); 
}