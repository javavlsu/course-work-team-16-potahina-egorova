package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*; 

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class TaskDAOImpl implements TaskDAO {
	public void create(Task task) { 
		DBImpl impl = DBImpl.init(); 
		impl.tasks.put(task.getId(), task);
	} 

	public void update(Task task) { 
		DBImpl impl = DBImpl.init(); 
		impl.tasks.put(task.getId(), task);
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.tasks.remove(id);
	} 

	public Task getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.tasks.get(id);
	} 

	public List<Task> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList<Task> list = new ArrayList<>(impl.tasks.values()); 
		return list;
	} 
}