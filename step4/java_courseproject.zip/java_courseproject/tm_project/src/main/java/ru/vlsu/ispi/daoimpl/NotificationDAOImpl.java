package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*;

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class NotificationDAOImpl implements NotificationDAO {
	public void create(Notification notification) { 
		DBImpl impl = DBImpl.init(); 
		impl.notifications.put(notification.getId(), notification);
	} 

	public void update(Notification notification) { 
		DBImpl impl = DBImpl.init(); 
		impl.notifications.put(notification.getId(), notification);
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.notifications.remove(id);
	} 

	public Notification getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.notifications.get(id);
	} 

	public List<Notification> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.notifications.values()); 
		return list; 
	} 
}