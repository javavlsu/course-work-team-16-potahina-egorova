package ru.vlsu.ispi.beans; 

import java.time.LocalDateTime; 

public class TaskList extends BaseBean {
	private int id; 
	private String title; 
	private int user_id; 

	public void setTitle(String title) {
		this.title = title; 
	} 

	public String getTitle() {
		return this.title; 
	} 

	public void setUserId(int user_id) {
		this.user_id = user_id; 
	} 

	public int getUserId() {
		return this.user_id; 
	}
}