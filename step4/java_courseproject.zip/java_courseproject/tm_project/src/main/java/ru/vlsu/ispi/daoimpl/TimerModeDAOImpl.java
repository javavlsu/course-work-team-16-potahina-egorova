package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*; 

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class TimerModeDAOImpl implements TimerModeDAO {
	public void create(TimerMode timer_mode) { 
		DBImpl impl = DBImpl.init(); 
		impl.timer_modes.put(timer_mode.getId(), timer_mode);
	} 

	public void update(TimerMode timer_mode) { 
		DBImpl impl = DBImpl.init(); 
		impl.timer_modes.put(timer_mode.getId(), timer_mode);
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.timer_modes.remove(id);
	} 

	public TimerMode getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.timer_modes.get(id);
	} 

	public List<TimerMode> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.timer_modes.values()); 
		return list;
	} 
}