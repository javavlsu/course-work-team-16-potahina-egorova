package ru.vlsu.ispi.beans; 

public class TaskExecutionLog extends BaseBean {
	private int id; 
	private int user_id; 
	private int task_id; 
	private int music_media_id; 
	private int visual_media_id;
	private int timer_mode_id;  

	public void setMusicMediaId(int music_media_id) {
		this.music_media_id = music_media_id; 
	} 

	public int getMusicMediaId() {
		return this.music_media_id; 
	}  

	public void setVisualMediaId(int visual_media_id) {
		this.visual_media_id = visual_media_id; 
	} 

	public int getVisualMediaId() {
		return this.visual_media_id; 
	} 

	public void setTimerModeId(int timer_mode_id) {
		this.timer_mode_id = timer_mode_id; 
	} 

	public int getTimerModeId() {
		return this.timer_mode_id; 
	} 
}