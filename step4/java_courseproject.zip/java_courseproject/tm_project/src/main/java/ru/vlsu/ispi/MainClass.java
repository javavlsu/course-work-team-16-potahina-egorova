package ru.vlsu.ispi; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*; 
import ru.vlsu.ispi.daoimpl.*;  

import java.util.List; 
import java.util.Map; 
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainClass {
	public static void main(String[] arg) {
		UserDAOImpl userDAOImpl = new UserDAOImpl(); 

		User user = new User(); 
		user.setId(1); 
		user.setName("Витя"); 
		user.setPassword("top_secret_12345"); 
		user.setEmail("vitya156@mail.ru"); 
		user.setPhoneNumber("+79036735881"); 
		user.setTotalPoints(150); 

		userDAOImpl.create(user);  

		User user2 = new User(); 
		user2.setId(2); 
		user2.setName("Алина"); 
		user2.setPassword("12345abc563"); 
		user2.setEmail("alinaaa123@mail.ru"); 
		user2.setPhoneNumber("+79083424573"); 
		user2.setTotalPoints(500); 

		userDAOImpl.create(user2);  

		List<User> users = userDAOImpl.getAll(); 
		for(User u: users) {
			System.out.println(u); 
		}

		TaskDAOImpl taskDAOImpl = new TaskDAOImpl(); 

		Task task = new Task(); 
		task.setId(1); 
		task.setTitle("Решить задачу по математике"); 
		task.setCategory("Школа"); 
		task.setTaskListId(5); 
		task.setStatus("Активно"); 
		task.setDetails("Решить задачу №5 из учебника по математике за 10 класс"); 
		String deadlineStr = "2025-04-15T12:30"; 
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
		LocalDateTime deadline = LocalDateTime.parse(deadlineStr, formatter);
		task.setDeadlineAt(deadline); 
		task.setPoints(50);

		taskDAOImpl.create(task); 

		Task task2 = new Task(); 
		task2.setId(3); 
		task2.setTitle("Написать доклад по истории"); 
		task2.setCategory("Вуз"); 
		task2.setTaskListId(3); 
		task2.setStatus("Выполнено"); 
		task2.setDetails("Написать доклад по истории на тему Бородинское сражение"); 
		String deadlineStr2 = "2025-09-30T17:00";
		LocalDateTime deadline2 = LocalDateTime.parse(deadlineStr2, formatter);
		task2.setDeadlineAt(deadline2);  
		task2.setPoints(100);

		taskDAOImpl.create(task2); 

		List<Task> tasks = taskDAOImpl.getAll(); 
		for(Task t: tasks) {
			System.out.println(t); 
		}
	}
}