package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*; 

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class UserAchievementDAOImpl implements UserAchievementDAO {
	public void create(UserAchievement user_achievement) { 
		DBImpl impl = DBImpl.init(); 
		impl.user_achievements.put(user_achievement.getId(), user_achievement);
	} 

	public void update(UserAchievement user_achievement) { 
		DBImpl impl = DBImpl.init(); 
		impl.user_achievements.put(user_achievement.getId(), user_achievement);
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.user_achievements.remove(id);
	} 

	public UserAchievement getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.user_achievements.get(id);
	} 

	public List<UserAchievement> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.user_achievements.values()); 
		return list; 
	} 
}