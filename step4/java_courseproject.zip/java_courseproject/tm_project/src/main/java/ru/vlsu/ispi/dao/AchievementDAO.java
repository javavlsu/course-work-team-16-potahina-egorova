package ru.vlsu.ispi.dao; 

import ru.vlsu.ispi.beans.*; 

import java.util.List;
import java.util.Map;

public interface AchievementDAO {
	public void create(Achievement achievement);

	public void update(Achievement achievement);

	public void delete(int id);

	public Achievement getById(int id);

	public List<Achievement> getAll();
}