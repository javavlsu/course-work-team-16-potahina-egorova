package ru.vlsu.ispi.daoimpl; 

import ru.vlsu.ispi.beans.*; 
import ru.vlsu.ispi.dao.*; 

import java.util.List; 
import java.util.Map;
import java.util.ArrayList;

public class TaskExecutionLogDAOImpl implements TaskExecutionLogDAO {
	public void create(TaskExecutionLog log) { 
		DBImpl impl = DBImpl.init(); 
		impl.logs.put(log.getId(), log); 
	} 

	public void update(TaskExecutionLog log) { 
		DBImpl impl = DBImpl.init(); 
		impl.logs.put(log.getId(), log);
	} 

	public void delete(int id) { 
		DBImpl impl = DBImpl.init(); 
		impl.logs.remove(id);
	} 

	public TaskExecutionLog getById(int id) { 
		DBImpl impl = DBImpl.init(); 
		return impl.logs.get(id);
	} 

	public List<TaskExecutionLog> getAll() { 
		DBImpl impl = DBImpl.init(); 
		ArrayList list = new ArrayList<>(impl.logs.values()); 
		return list; 
	} 
}