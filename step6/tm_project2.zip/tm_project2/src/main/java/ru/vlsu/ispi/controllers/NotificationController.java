package ru.vlsu.ispi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ru.vlsu.ispi.dao.NotificationDAO;
import ru.vlsu.ispi.dao.TaskDAO;

@Controller
public class NotificationController {
    private final NotificationDAO notificationDAO;

    @Autowired
    public NotificationController(NotificationDAO notificationDAO) {
        this.notificationDAO = notificationDAO;
    }

    @GetMapping("/notifications")
    public String showNotifications(Model model) {
        return "notifications";
    }
}
