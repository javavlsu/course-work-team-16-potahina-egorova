package ru.vlsu.ispi.beans;

public class TimerMode extends BaseBean {
	private int id; 
	private String mode_name; 
	private int work_duration_min; 
	private int short_break_min; 
	private int long_break_min; 
	private String mode_description; 

	public void setModeName(String mode_name) {
		this.mode_name = mode_name; 
	} 

	public String getModeName() {
		return this.mode_name; 
	} 

	public void setWorkDurationMin(int work_duration_min) {
		this.work_duration_min = work_duration_min; 
	} 

	public int getWorkDurationMin() {
		return this.work_duration_min; 
	} 

	public void setShortBreakMin(int short_break_min) {
		this.short_break_min = short_break_min; 
	} 

	public int getShortBreakMin() {
		return this.short_break_min; 
	} 

	public void setLongBreakMin(int long_break_min) {
		this.long_break_min = long_break_min; 
	} 

	public int getLongBreakMin() {
		return this.long_break_min; 
	}  

	public void setModeDescription(String mode_description) {
		this.mode_description = mode_description; 
	} 

	public String getModeDescription() {
		return this.mode_description; 
	} 
}