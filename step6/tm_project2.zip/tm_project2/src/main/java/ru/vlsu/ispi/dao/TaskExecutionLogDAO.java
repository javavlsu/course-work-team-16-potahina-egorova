package ru.vlsu.ispi.dao;

import org.springframework.stereotype.Component;
import ru.vlsu.ispi.beans.Task;
import ru.vlsu.ispi.beans.TaskExecutionLog;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class TaskExecutionLogDAO {
    private List<TaskExecutionLog> taskExecutionLogs = new ArrayList<>();
    private AtomicInteger ID_GENERATOR = new AtomicInteger(1); // Для генерации ID

    public TaskExecutionLogDAO() {
        TaskExecutionLog l1 = new TaskExecutionLog();
        taskExecutionLogs.add(l1);
    }

    public void create(TaskExecutionLog taskExecutionLog) {
        taskExecutionLog.setId(ID_GENERATOR.getAndIncrement());
        taskExecutionLogs.add(taskExecutionLog);
    }

    public void update(TaskExecutionLog taskExecutionLog) {
        // Находим задачу по ID и заменяем (упрощенно)
        for (int i = 0; i < taskExecutionLogs.size(); i++) {
            if (taskExecutionLogs.get(i).getId() == taskExecutionLog.getId()) {
                taskExecutionLogs.set(i, taskExecutionLog);
                return;
            }
        }
    }

    public void delete(int id) {
        taskExecutionLogs.removeIf(t -> t.getId() == id);
    }

    public TaskExecutionLog getById(int id) {
        return taskExecutionLogs.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<TaskExecutionLog> getAll() {
        return taskExecutionLogs;
    }
}
