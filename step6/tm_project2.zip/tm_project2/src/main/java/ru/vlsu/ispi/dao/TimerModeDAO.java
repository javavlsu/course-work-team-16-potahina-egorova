package ru.vlsu.ispi.dao;

import org.springframework.stereotype.Component;
import ru.vlsu.ispi.beans.Task;
import ru.vlsu.ispi.beans.TimerMode;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class TimerModeDAO {
    private List<TimerMode> timerModes = new ArrayList<>();
    private AtomicInteger ID_GENERATOR = new AtomicInteger(1); // Для генерации ID

    public TimerModeDAO() {
        TimerMode tm1 = new TimerMode();
        timerModes.add(tm1);
    }

    public void create(TimerMode timerMode) {
        timerMode.setId(ID_GENERATOR.getAndIncrement());
        timerModes.add(timerMode);
    }

    public void update(TimerMode timerMode) {
        // Находим задачу по ID и заменяем (упрощенно)
        for (int i = 0; i < timerModes.size(); i++) {
            if (timerModes.get(i).getId() == timerMode.getId()) {
                timerModes.set(i, timerMode);
                return;
            }
        }
    }

    public void delete(int id) {
        timerModes.removeIf(t -> t.getId() == id);
    }

    public TimerMode getById(int id) {
        return timerModes.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<TimerMode> getAll() {
        return timerModes;
    }
}
