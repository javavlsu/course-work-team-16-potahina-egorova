package ru.vlsu.ispi.controllers;

import ru.vlsu.ispi.beans.TimerMode;
import ru.vlsu.ispi.dao.TimerModeDAO;

import java.util.List;

public class TimerModeController {
    private TimerModeDAO timerModeDAO;

    public TimerModeController(TimerModeDAO timerModeDAO) {
        this.timerModeDAO = timerModeDAO;
    }

    public void createTimerMode(TimerMode timerMode) {
        System.out.println("Create timerMode: " + String.valueOf(timerMode));
        this.timerModeDAO.create(timerMode);
    }

    public void updateTimerMode(TimerMode timerMode) {
        System.out.println("Update timerMode: " + String.valueOf(timerMode));
        this.timerModeDAO.update(timerMode);
    }

    public void deleteTimerMode(int id) {
        System.out.println("Delete timerMode with id: " + id);
        this.timerModeDAO.delete(id);
    }

    public TimerMode getTimerModeById(int id) {
        System.out.println("Get timerMode by id: " + id);
        return this.timerModeDAO.getById(id);
    }

    public List<TimerMode> getAllTimerModes() {
        System.out.println("Get all timerModes");
        return this.timerModeDAO.getAll();
    }
}
