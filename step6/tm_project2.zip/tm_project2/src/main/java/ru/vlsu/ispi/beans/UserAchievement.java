package ru.vlsu.ispi.beans; 

import java.util.Date; 

public class UserAchievement extends BaseBean {
	private int id; 
	private int user_id; 
	private int achievement_id; 
	private Date achieved_date; 

	public void setUserId(int user_id) {
		this.user_id = user_id; 
	} 

	public int getUserId() {
		return this.user_id; 
	} 

	public void setAchievementId(int achievement_id) {
		this.achievement_id = achievement_id; 
	} 

	public int getAchievementId() {
		return this.achievement_id; 
	} 

	public void setAchievedDate(Date achieved_date) {
		this.achieved_date = achieved_date; 
	} 

	public Date getAchievedDate() {
		return this.achieved_date; 
	}
}