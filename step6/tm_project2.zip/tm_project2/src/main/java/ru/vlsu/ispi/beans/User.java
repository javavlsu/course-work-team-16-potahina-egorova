package ru.vlsu.ispi.beans;

public class User extends BaseBean {
	private int id; 
	private String name; 
	private String password; 
	private String email; 
	private String phone_number; 
	private int total_points; 

	public void setName(String name) {
		this.name = name; 
	} 

	public String getName() {
		return this.name; 
	} 

	public void setPassword(String password) {
		this.password = password; 
	} 

	public String getPassword() {
		return this.password; 
	} 

	public void setEmail(String email) {
		this.email = email; 
	} 

	public String getEmail() {
		return this.email; 
	} 

	public void setPhoneNumber(String phone_number) {
		this.phone_number = phone_number; 
	} 

	public String getPhoneNumber() {
		return this.phone_number; 
	}  

	public void setTotalPoints(int total_points) {
		this.total_points = total_points; 
	} 

	public int getTotalPoints() {
		return this.total_points; 
	}  

	public String toString() {
		return this.getId() + " " + this.name + " " + this.total_points;
	}
}