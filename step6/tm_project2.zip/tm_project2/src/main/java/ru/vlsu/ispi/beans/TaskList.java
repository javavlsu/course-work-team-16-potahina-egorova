package ru.vlsu.ispi.beans;

public class TaskList {
	private int id; 
	private String title;

	public Integer getId() { return id; }
	public void setId(int id) { this.id = id; }

	public void setTitle(String title) {
		this.title = title; 
	} 

	public String getTitle() {
		return this.title; 
	}
}