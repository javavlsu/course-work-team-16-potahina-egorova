package ru.vlsu.ispi.dao;

import org.springframework.stereotype.Component;
import ru.vlsu.ispi.beans.Notification;
import ru.vlsu.ispi.beans.Task;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class NotificationDAO {
    private List<Notification> notifications = new ArrayList<>();
    private AtomicInteger ID_GENERATOR = new AtomicInteger(1); // Для генерации ID

    public NotificationDAO() {
        Notification n1 = new Notification();
        notifications.add(n1);
    }

    public void create(Notification notification) {
        notification.setId(ID_GENERATOR.getAndIncrement());
        notifications.add(notification);
    }

    public void update(Notification notification) {
        // Находим задачу по ID и заменяем (упрощенно)
        for (int i = 0; i < notifications.size(); i++) {
            if (notifications.get(i).getId() == notification.getId()) {
                notifications.set(i, notification);
                return;
            }
        }
    }

    public void delete(int id) {
        notifications.removeIf(t -> t.getId() == id);
    }

    public Notification getById(int id) {
        return notifications.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<Notification> getAll() {
        return notifications;
    }
}
