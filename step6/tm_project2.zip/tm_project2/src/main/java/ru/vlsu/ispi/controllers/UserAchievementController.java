package ru.vlsu.ispi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ru.vlsu.ispi.dao.UserAchievementDAO;
import ru.vlsu.ispi.dao.UserDAO;

@Controller
public class UserAchievementController {
    private final UserAchievementDAO userAchievementDAO;

    @Autowired
    public UserAchievementController(UserAchievementDAO userAchievementDAO) {
        this.userAchievementDAO = userAchievementDAO;
    }
}
