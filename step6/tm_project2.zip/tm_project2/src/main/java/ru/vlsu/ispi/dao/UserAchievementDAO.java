package ru.vlsu.ispi.dao;

import org.springframework.stereotype.Component;
import ru.vlsu.ispi.beans.User;
import ru.vlsu.ispi.beans.UserAchievement;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class UserAchievementDAO {
    private List<UserAchievement> userAchievements = new ArrayList<>();
    private AtomicInteger ID_GENERATOR = new AtomicInteger(1); // Для генерации ID

    public UserAchievementDAO() {
        UserAchievement ua1 = new UserAchievement();
        userAchievements.add(ua1);
    }

    public void create(UserAchievement userAchievement) {
        userAchievement.setId(ID_GENERATOR.getAndIncrement());
        userAchievements.add(userAchievement);
    }

    public void update(UserAchievement userAchievement) {
        // Находим задачу по ID и заменяем (упрощенно)
        for (int i = 0; i < userAchievements.size(); i++) {
            if (userAchievements.get(i).getId() == userAchievement.getId()) {
                userAchievements.set(i, userAchievement);
                return;
            }
        }
    }

    public void delete(int id) {
        userAchievements.removeIf(t -> t.getId() == id);
    }

    public UserAchievement getById(int id) {
        return userAchievements.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<UserAchievement> getAll() {
        return userAchievements;
    }
}
