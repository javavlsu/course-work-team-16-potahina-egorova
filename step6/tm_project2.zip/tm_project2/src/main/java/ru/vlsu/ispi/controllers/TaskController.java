package ru.vlsu.ispi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller; // Импорт Spring
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ru.vlsu.ispi.beans.Task;
import ru.vlsu.ispi.dao.TaskDAO;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Controller
public class TaskController {
    private final TaskDAO taskDAO;

    @Autowired
    public TaskController(TaskDAO taskDAO) {
        this.taskDAO = taskDAO;
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/index";
    }

    @GetMapping("/task")
    public String showTask(Model model) {
        return "task";
    }

    @GetMapping("/table")
    public String showTable(Model model) {
        LocalDate now = LocalDate.now();

        int currentDay = now.getDayOfMonth();

        // Передаем в модель
        model.addAttribute("currentDay", currentDay);

        List<Task> allTasks = taskDAO.getAll();

        model.addAttribute("tasks", allTasks);

        // Пример заполнения todayTasks теми же задачами
        model.addAttribute("todayTasks", allTasks);

        // Формируем список дней, на которые есть задачи
        Set<Integer> taskDaysSet = new HashSet<>();
        for (Task task : allTasks) {
            LocalDateTime dt = task.getDeadlineAt();
            taskDaysSet.add(dt.getDayOfMonth());
        }
        // Преобразуем в список и добавляем в модель
        List<Integer> taskDays = new ArrayList<>(taskDaysSet);
        model.addAttribute("taskDays", taskDays);

        return "table";
    }

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        List<Task> allTasks = taskDAO.getAll(); // Получение всех задач из DAO

        if (!allTasks.isEmpty()) { // Проверяем наличие задач
            model.addAttribute("tasks", allTasks); // Добавляем список задач в модель
        } else {
            model.addAttribute("tasks", Collections.emptyList()); // Или добавляем пустой список
        }

        LocalDate now = LocalDate.now();

        int currentDay = now.getDayOfMonth();

        // Передаем в модель
        model.addAttribute("currentDay", currentDay);

        Set<Integer> taskDaysSet = new HashSet<>();
        for (Task task : allTasks) {
            LocalDateTime dt = task.getDeadlineAt();
            taskDaysSet.add(dt.getDayOfMonth());
        }

        List<Integer> taskDays = new ArrayList<>(taskDaysSet);
        model.addAttribute("taskDays", taskDays);

        return "dashboard";
    }

    @PostMapping("/add-task")
    public String createTask(@ModelAttribute Task task) {
        // Spring автоматически собирает поля из формы в объект Task
        System.out.println("Создана задача: " + task);

        taskDAO.create(task);

        return "redirect:/table";
    }

    @PostMapping("/edit-task/{id}")
    public String updateTask(@PathVariable Integer id, @ModelAttribute Task updatedTask) {
        if (!updatedTask.getId().equals(id)) {
            throw new IllegalArgumentException("Идентификатор задачи не совпадает");
        }

        taskDAO.update(updatedTask);

        return "redirect:/table";
    }

    @DeleteMapping("/delete-task/{id}")
    @ResponseBody
    public ResponseEntity<Void> deleteTask(@PathVariable Integer id) {
        taskDAO.delete(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/edit-task/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        Task taskToEdit = taskDAO.getById(id);
        if (taskToEdit != null) {
            model.addAttribute("task", taskToEdit);
        }
        return "edit-form";
    }

    @GetMapping("/view-task/{id}")
    public String viewTask(@PathVariable Integer id, Model model) {
        Task taskToView = taskDAO.getById(id);
        if (taskToView != null) {
            model.addAttribute("task", taskToView);
        }
        return "view-task";
    }
}