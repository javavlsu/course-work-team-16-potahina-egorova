package ru.vlsu.ispi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ru.vlsu.ispi.beans.Task;
import ru.vlsu.ispi.beans.TaskList;
import ru.vlsu.ispi.dao.TaskDAO;
import ru.vlsu.ispi.dao.TaskListDAO;

import java.util.List;

public class TaskListController {
    private final TaskListDAO taskListDAO;

    @Autowired
    public TaskListController(TaskListDAO taskListDAO) {
        this.taskListDAO = taskListDAO;
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/table";
    }

    @GetMapping("/table")
    public String showTable(Model model) {
        List<TaskList> allTaskLists = taskListDAO.getAll();

        // Передаем данные в Thymeleaf
        // Имя "tasks" должно совпадать с th:each="task : ${tasks}" в HTML
        model.addAttribute("taskLists", allTaskLists);

        return "table"; // Имя html-файла без расширения
    }

    @PostMapping("/add-task-list")
    public String createTaskList(@ModelAttribute TaskList taskList) {
        System.out.println("Создан список: " + taskList);

        taskListDAO.create(taskList);

        return "redirect:/table";
    }

    @PostMapping("/edit-task-list/{id}")
    public String updateTaskList(@PathVariable Integer id, @ModelAttribute TaskList updatedTaskList) {
        if (!updatedTaskList.getId().equals(id)) {
            throw new IllegalArgumentException("Идентификатор задачи не совпадает");
        }

        taskListDAO.update(updatedTaskList);

        return "redirect:/table";
    }

    @DeleteMapping("/delete-task/{id}")
    public String deleteTaskList(@PathVariable Integer id) {
        taskListDAO.delete(id);

        return "redirect:/table";
    }

    @GetMapping("/edit-task-list/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        TaskList taskListToEdit = taskListDAO.getById(id);
        if (taskListToEdit != null) {
            model.addAttribute("taskList", taskListToEdit);
        }
        return "edit-form"; // Представляет форму редактирования
    }

    @GetMapping("/view-task-list/{id}")
    public String viewTaskList(@PathVariable Integer id, Model model) {
        TaskList taskListToView = taskListDAO.getById(id);
        if (taskListToView != null) {
            model.addAttribute("taskList", taskListToView);
        }
        return "view-task-list";
    }
}
