package ru.vlsu.ispi.dao;

import org.springframework.stereotype.Component;
import ru.vlsu.ispi.beans.Achievement;
import ru.vlsu.ispi.beans.Task;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class AchievementDAO {
    private List<Achievement> achievements = new ArrayList<>();
    private AtomicInteger ID_GENERATOR = new AtomicInteger(1); // Для генерации ID

    public AchievementDAO() {
        Achievement a1 = new Achievement();
        achievements.add(a1);
    }

    public void create(Achievement achievement) {
        achievement.setId(ID_GENERATOR.getAndIncrement());
        achievements.add(achievement);
    }

    public void update(Achievement achievement) {
        // Находим задачу по ID и заменяем (упрощенно)
        for (int i = 0; i < achievements.size(); i++) {
            if (achievements.get(i).getId() == achievement.getId()) {
                achievements.set(i, achievement);
                return;
            }
        }
    }

    public void delete(int id) {
        achievements.removeIf(t -> t.getId() == id);
    }

    public Achievement getById(int id) {
        return achievements.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<Achievement> getAll() {
        return achievements;
    }
}
