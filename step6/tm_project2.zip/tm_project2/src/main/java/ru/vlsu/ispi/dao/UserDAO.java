package ru.vlsu.ispi.dao;

import org.springframework.stereotype.Component;
import ru.vlsu.ispi.beans.Task;
import ru.vlsu.ispi.beans.User;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class UserDAO {
    private List<User> users = new ArrayList<>();
    private AtomicInteger ID_GENERATOR = new AtomicInteger(1); // Для генерации ID

    public UserDAO() {
        User u1 = new User();
        users.add(u1);
    }

    public void create(User user) {
        user.setId(ID_GENERATOR.getAndIncrement());
        users.add(user);
    }

    public void update(User user) {
        // Находим задачу по ID и заменяем (упрощенно)
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == user.getId()) {
                users.set(i, user);
                return;
            }
        }
    }

    public void delete(int id) {
        users.removeIf(t -> t.getId() == id);
    }

    public User getById(int id) {
        return users.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<User> getAll() {
        return users;
    }
}