package ru.vlsu.ispi.dao;

import org.springframework.stereotype.Component;
import ru.vlsu.ispi.beans.Task;
import ru.vlsu.ispi.daoimpl.DBImpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class TaskDAO {
	private List<Task> tasks = new ArrayList<>();
	private AtomicInteger ID_GENERATOR = new AtomicInteger(1); // Для генерации ID

	public TaskDAO() {
		Task t1 = new Task();
		t1.setId(ID_GENERATOR.getAndIncrement());
		t1.setTitle("Сделать лабораторную");
		t1.setDetails("Java MVC");
		LocalDateTime deadline = LocalDateTime.of(2025, 12, 31, 23, 59);
		t1.setDeadlineAt(deadline);
		tasks.add(t1);

		Task t2 = new Task();
		t2.setId(ID_GENERATOR.getAndIncrement());
		t2.setTitle("Сделать курсач");
		t2.setDetails("Java MVC");
		deadline = LocalDateTime.of(2025, 12, 25, 15, 30);
		t2.setDeadlineAt(deadline);
		tasks.add(t2);
	}

	public void create(Task task) {
		task.setId(ID_GENERATOR.getAndIncrement());
		tasks.add(task);
	}

	public void update(Task task) {
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getId() == task.getId()) {
				tasks.set(i, task);
				return;
			}
		}
	}

	public void delete(int id) {
		tasks.removeIf(t -> t.getId() == id);
	}

	public Task getById(int id) {
		return tasks.stream()
				.filter(t -> t.getId() == id)
				.findFirst()
				.orElse(null);
	}

	public List<Task> getAll() {
		return tasks;
	}
}