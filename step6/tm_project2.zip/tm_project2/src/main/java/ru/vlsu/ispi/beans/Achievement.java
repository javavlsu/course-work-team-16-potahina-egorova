package ru.vlsu.ispi.beans;

public class Achievement extends BaseBean {
	private int id; 
	private String title; 
	private String description; 
	private int reward_points; 

	public void setTitle(String title) {
		this.title = title; 
	} 

	public String getTitle() {
		return this.title; 
	} 

	public void setDescription(String description) {
		this.description = description; 
	} 

	public String getDescription() {
		return this.description; 
	} 

	public void setRewardPoints(int reward_points) {
		this.reward_points = reward_points; 
	} 

	public int getRewardPoints() {
		return this.reward_points; 
	} 
}