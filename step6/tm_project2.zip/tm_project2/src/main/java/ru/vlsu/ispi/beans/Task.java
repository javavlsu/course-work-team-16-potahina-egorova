package ru.vlsu.ispi.beans; 

import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

public class Task {
	private int id; 
	private String title; 
	private String category; 
	private int task_list_id; 
	private String status; 
	private String details;
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
	private LocalDateTime deadline_at; 
	private int points;

	public void setId(int id) {
		this.id = id;
	}

	public Integer getId() {
		return this.id;
	}

	public void setTitle(String title) {
		this.title = title; 
	} 

	public String getTitle() {
		return this.title; 
	} 

	public void setCategory(String category) {
		this.category = category; 
	} 

	public String getCategory() {
		return this.category; 
	} 

	public void setTaskListId(int task_list_id) {
		this.task_list_id = task_list_id; 
	} 

	public int getTaskListId() {
		return this.task_list_id; 
	}

	public void setStatus(String status) {
		this.status = status; 
	} 

	public String getStatus() {
		return this.status; 
	} 

	public void setDetails(String details) {
		this.details = details; 
	} 

	public String getDetails() {
		return this.details; 
	}  

	public void setDeadlineAt(LocalDateTime deadline_at) {
		this.deadline_at = deadline_at; 
	} 

	public LocalDateTime getDeadlineAt() {
		return this.deadline_at; 
	} 

	public void setPoints(int points) {
		this.points = points; 
	} 

	public int getPoints() {
		return this.points; 
	} 

	public String toString() {
		return this.getId() + " " + this.title + " " + this.category + " " + this.status + " " + this.details + " " + this.deadline_at + " " + this.points;
	}
}