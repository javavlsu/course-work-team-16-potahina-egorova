package ru.vlsu.ispi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ru.vlsu.ispi.beans.Achievement;
import ru.vlsu.ispi.dao.AchievementDAO;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Controller
public class AchievementController {
    private final AchievementDAO achievementDAO;

    @Autowired
    public AchievementController(AchievementDAO achievementDAO) {
        this.achievementDAO = achievementDAO;
    }
    @GetMapping("/achievements")
    public String showAchievements(Model model) {
        return "achievements";
    }
}
