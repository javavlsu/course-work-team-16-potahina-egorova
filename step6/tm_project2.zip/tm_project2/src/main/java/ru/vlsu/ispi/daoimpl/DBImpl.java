package ru.vlsu.ispi.daoimpl;

import ru.vlsu.ispi.beans.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DBImpl {
	// Maps for storing entities
	public Map<Integer, User> users;
	public Map<Integer, Task> tasks;
	public Map<Integer, TaskList> taskLists;
	public Map<Integer, TaskExecutionLog> logs;
	public Map<Integer, Achievement> achievements;
	public Map<Integer, UserAchievement> userAchievements;
	public Map<Integer, TimerMode> timerModes;
	public Map<Integer, MusicMedia> musicMediaT;
	public Map<Integer, VisualMedia> visualMediaT;
	public Map<Integer, Notification> notifications;

	// Counter variables to generate unique IDs
	private int userIdCounter = 1;
	private int taskIdCounter = 1;
	private int taskListIdCounter = 1;
	private int logIdCounter = 1;
	private int achievementIdCounter = 1;
	private int userAchievementIdCounter = 1;
	private int timerModeIdCounter = 1;
	private int musicMediaTIdCounter = 1;
	private int visualMediaTIdCounter = 1;
	private int notificationIdCounter = 1;

	// Singleton pattern implementation
	private static DBImpl instance = new DBImpl();

	private DBImpl() {
		this.users = new HashMap<>();
		this.tasks = new HashMap<>();
		this.taskLists = new HashMap<>();
		this.logs = new HashMap<>();
		this.achievements = new HashMap<>();
		this.userAchievements = new HashMap<>();
		this.timerModes = new HashMap<>();
		this.musicMediaT = new HashMap<>();
		this.visualMediaT = new HashMap<>();
		this.notifications = new HashMap<>();
	}

	public static DBImpl init() {
		return instance;
	}

	// Methods for managing Users
	public User createUser(User user) {
		user.setId(userIdCounter++);
		users.put(user.getId(), user);
		return user;
	}

	public void updateUser(User user) {
		users.put(user.getId(), user);
	}

	public void deleteUser(int id) {
		users.remove(id);
	}

	public List<User> getAllUsers() {
		return new ArrayList<>(users.values());
	}

	public User getUserById(int id) {
		return users.get(id);
	}

	// Methods for managing Tasks
	public Task createTask(Task task) {
		task.setId(taskIdCounter++);
		tasks.put(task.getId(), task);
		return task;
	}

	public void updateTask(Task task) {
		tasks.put(task.getId(), task);
	}

	public void deleteTask(int id) {
		tasks.remove(id);
	}

	public List<Task> getAllTasks() {
		return new ArrayList<>(tasks.values());
	}

	public Task getTaskById(int id) {
		return tasks.get(id);
	}

	// Methods for managing Task Lists
	public TaskList createTaskList(TaskList taskList) {
		taskList.setId(taskListIdCounter++);
		taskLists.put(taskList.getId(), taskList);
		return taskList;
	}

	public void updateTaskList(TaskList taskList) {
		taskLists.put(taskList.getId(), taskList);
	}

	public void deleteTaskList(int id) {
		taskLists.remove(id);
	}

	public List<TaskList> getAllTaskLists() {
		return new ArrayList<>(taskLists.values());
	}

	public TaskList getTaskListById(int id) {
		return taskLists.get(id);
	}

	// Methods for managing Execution Logs
	public TaskExecutionLog createLog(TaskExecutionLog log) {
		log.setId(logIdCounter++);
		logs.put(log.getId(), log);
		return log;
	}

	public void updateLog(TaskExecutionLog log) {
		logs.put(log.getId(), log);
	}

	public void deleteLog(int id) {
		logs.remove(id);
	}

	public List<TaskExecutionLog> getAllLogs() {
		return new ArrayList<>(logs.values());
	}

	public TaskExecutionLog getLogById(int id) {
		return logs.get(id);
	}

	// Methods for managing Achievements
	public Achievement createAchievement(Achievement achievement) {
		achievement.setId(achievementIdCounter++);
		achievements.put(achievement.getId(), achievement);
		return achievement;
	}

	public void updateAchievement(Achievement achievement) {
		achievements.put(achievement.getId(), achievement);
	}

	public void deleteAchievement(int id) {
		achievements.remove(id);
	}

	public List<Achievement> getAllAchievements() {
		return new ArrayList<>(achievements.values());
	}

	public Achievement getAchievementById(int id) {
		return achievements.get(id);
	}

	// Methods for managing User Achievements
	public UserAchievement createUserAchievement(UserAchievement userAchievement) {
		userAchievement.setId(userAchievementIdCounter++);
		userAchievements.put(userAchievement.getId(), userAchievement);
		return userAchievement;
	}

	public void updateUserAchievement(UserAchievement userAchievement) {
		userAchievements.put(userAchievement.getId(), userAchievement);
	}

	public void deleteUserAchievement(int id) {
		userAchievements.remove(id);
	}

	public List<UserAchievement> getAllUserAchievements() {
		return new ArrayList<>(userAchievements.values());
	}

	public UserAchievement getUserAchievementById(int id) {
		return userAchievements.get(id);
	}

	// Methods for managing Timer Modes
	public TimerMode createTimerMode(TimerMode timerMode) {
		timerMode.setId(timerModeIdCounter++);
		timerModes.put(timerMode.getId(), timerMode);
		return timerMode;
	}

	public void updateTimerMode(TimerMode timerMode) {
		timerModes.put(timerMode.getId(), timerMode);
	}

	public void deleteTimerMode(int id) {
		timerModes.remove(id);
	}

	public List<TimerMode> getAllTimerModes() {
		return new ArrayList<>(timerModes.values());
	}

	public TimerMode getTimerModeById(int id) {
		return timerModes.get(id);
	}

	// Methods for managing Music Media Types
	public MusicMedia createMusicMedia(MusicMedia musicMedia) {
		musicMedia.setId(musicMediaTIdCounter++);
		musicMediaT.put(musicMedia.getId(), musicMedia);
		return musicMedia;
	}

	public void updateMusicMedia(MusicMedia musicMedia) {
		musicMediaT.put(musicMedia.getId(), musicMedia);
	}

	public void deleteMusicMedia(int id) {
		musicMediaT.remove(id);
	}

	public List<MusicMedia> getAllMusicMediaTypes() {
		return new ArrayList<>(musicMediaT.values());
	}

	public MusicMedia getMusicMediaTypeById(int id) {
		return musicMediaT.get(id);
	}

	// Methods for managing Visual Media Types
	public VisualMedia createVisualMedia(VisualMedia visualMedia) {
		visualMedia.setId(visualMediaTIdCounter++);
		visualMediaT.put(visualMedia.getId(), visualMedia);
		return visualMedia;
	}

	public void updateVisualMedia(VisualMedia visualMedia) {
		visualMediaT.put(visualMedia.getId(), visualMedia);
	}

	public void deleteVisualMedia(int id) {
		visualMediaT.remove(id);
	}

	public List<VisualMedia> getAllVisualMediaTypes() {
		return new ArrayList<>(visualMediaT.values());
	}

	public VisualMedia getVisualMediaTypeById(int id) {
		return visualMediaT.get(id);
	}

	// Methods for managing Notifications
	public Notification createNotification(Notification notification) {
		notification.setId(notificationIdCounter++);
		notifications.put(notification.getId(), notification);
		return notification;
	}

	public void updateNotification(Notification notification) {
		notifications.put(notification.getId(), notification);
	}

	public void deleteNotification(int id) {
		notifications.remove(id);
	}

	public List<Notification> getAllNotifications() {
		return new ArrayList<>(notifications.values());
	}

	public Notification getNotificationById(int id) {
		return notifications.get(id);
	}
}