package ru.vlsu.ispi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import ru.vlsu.ispi.dao.TaskDAO;
import ru.vlsu.ispi.dao.TaskExecutionLogDAO;

@Controller
public class TaskExecutionLogController {
    private final TaskExecutionLogDAO taskExecutionLogDAO;

    @Autowired
    public TaskExecutionLogController(TaskExecutionLogDAO taskExecutionLogDAO) {
        this.taskExecutionLogDAO = taskExecutionLogDAO;
    }
}
