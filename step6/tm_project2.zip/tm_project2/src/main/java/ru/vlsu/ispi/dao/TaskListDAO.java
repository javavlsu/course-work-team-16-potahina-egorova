package ru.vlsu.ispi.dao;

import ru.vlsu.ispi.beans.Task;
import ru.vlsu.ispi.beans.TaskList;
import ru.vlsu.ispi.daoimpl.DBImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class TaskListDAO {
	private List<TaskList> taskLists = new ArrayList<>();
	private AtomicInteger ID_GENERATOR = new AtomicInteger(1);

	public TaskListDAO() {
		// Добавим пару тестовых задач, чтобы таблица не была пустой
		TaskList tl1 = new TaskList();
		tl1.setId(ID_GENERATOR.getAndIncrement());
		tl1.setTitle("Список 1");
		taskLists.add(tl1);

		TaskList tl2 = new TaskList();
		tl2.setId(ID_GENERATOR.getAndIncrement());
		tl2.setTitle("Сделать курсач");
		taskLists.add(tl2);
	}

	public void create(TaskList taskList) {
		taskList.setId(ID_GENERATOR.getAndIncrement());
		taskLists.add(taskList);
	}

	public void update(TaskList taskList) {
		// Находим задачу по ID и заменяем (упрощенно)
		for (int i = 0; i < taskLists.size(); i++) {
			if (taskLists.get(i).getId() == taskList.getId()) {
				taskLists.set(i, taskList);
				return;
			}
		}
	}

	public void delete(int id) {
		taskLists.removeIf(t -> t.getId() == id);
	}

	public TaskList getById(int id) {
		return taskLists.stream()
				.filter(t -> t.getId() == id)
				.findFirst()
				.orElse(null);
	}

	public List<TaskList> getAll() {
		return taskLists;
	}
}